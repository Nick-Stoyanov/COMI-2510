/**
 * 
 */
package chapter8;

/**
 * @author Nikolay Stoyanov
 * Dec 6, 2022
 */
public class Metrics
{

	/**
	 * Default constructor
	 */
	public Metrics()
	{
		super();
	}

}
