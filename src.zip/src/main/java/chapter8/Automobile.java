/**
 * 
 */
package chapter8;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class Automobile
{

	private String name;

	/**
	 * @return the key
	 */
	public String getKey()
	{
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key)
	{
		this.key = key;
	}

	private String key;

	private double mgp = 0.0;

	/**
	 * @return the mgp
	 */
	public double getMgp()
	{
		return mgp;
	}

	/**
	 * @param mgp the mgp to set
	 */
	public void setMgp(double mgp)
	{
		this.mgp = mgp;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * Default constructor
	 */
	public Automobile()
	{
		super();
	}

}
