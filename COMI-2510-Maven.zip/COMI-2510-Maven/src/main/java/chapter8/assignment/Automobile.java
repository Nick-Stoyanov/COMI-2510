/**
 *
 */
package chapter8.assignment;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class Automobile
{

	FuelGauge fuelGauge = new FuelGauge();
	OilGauge oilGauge = new OilGauge();
	TireGauge tireGauge = new TireGauge();

	private String name =null;

	private String key =null;

	private double mgp = 0.0;



	/**
	 * Default constructor
	 */
	public Automobile()
	{
		super();
	}

	/**
	 * Overloaded constructor
	 * @param fuelGauge
	 * @param oilGauge
	 * @param tireGauge
	 * @param name
	 * @param key
	 * @param mgp
	 */
	public Automobile(FuelGauge fuelGauge, OilGauge oilGauge, TireGauge tireGauge, String name, String key, double mgp)
	{
		super();
		this.fuelGauge = fuelGauge;
		this.oilGauge = oilGauge;
		this.tireGauge = tireGauge;
		this.name = name;
		this.key = key;
		this.mgp = mgp;
	}

	/**
	 * @return the fuelGauge
	 */
	public FuelGauge getFuelGauge()
	{
		return fuelGauge;
	}

	/**
	 * @return the key
	 */
	public String getKey()
	{
		return key;
	}

	/**
	 * @return the mgp
	 */
	public double getMgp()
	{
		return mgp;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @return the oilGauge
	 */
	public OilGauge getOilGauge()
	{
		return oilGauge;
	}

	/**
	 * @return the tireGauge
	 */
	public TireGauge getTireGauge()
	{
		return tireGauge;
	}

	/**
	 * @param fuelGauge the fuelGauge to set
	 */
	public void setFuelGauge(FuelGauge fuelGauge)
	{
		this.fuelGauge = fuelGauge;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key)
	{
		this.key = key;
	}

	/**
	 * @param mgp the mgp to set
	 */
	public void setMgp(double mgp)
	{
		this.mgp = mgp;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * @param oilGauge the oilGauge to set
	 */
	public void setOilGauge(OilGauge oilGauge)
	{
		this.oilGauge = oilGauge;
	}

	/**
	 * @param tireGauge the tireGauge to set
	 */
	public void setTireGauge(TireGauge tireGauge)
	{
		this.tireGauge = tireGauge;
	}

}
