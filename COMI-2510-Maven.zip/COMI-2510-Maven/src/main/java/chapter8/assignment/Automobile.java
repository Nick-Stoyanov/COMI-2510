/**
 *
 */
package chapter8.assignment;

/**
 * Automobile
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class Automobile
{

	FuelGauge fuelGauge = new FuelGauge();
	OilGauge oilGauge = new OilGauge();
	TireGauge tireGauge = new TireGauge();

	private String name = null;

	private String key = null;

	private double mgp = 0.0;

	/**
	 * Default constructor
	 */
	public Automobile()
	{
		super();
	}

	/**
	 * Overloaded constructor
	 * 
	 * @param fuelGauge fuel gauge
	 * @param oilGauge  oil gauge
	 * @param tireGauge tire gauge
	 * @param name      name
	 * @param key       key
	 * @param mgp       mpg
	 */
	public Automobile(FuelGauge fuelGauge, OilGauge oilGauge, TireGauge tireGauge, String name, String key, double mgp)
	{
		super();
		this.fuelGauge = fuelGauge;
		this.oilGauge = oilGauge;
		this.tireGauge = tireGauge;
		this.name = name;
		this.key = key;
		this.mgp = mgp;
	}

	/**
	 * get fuel
	 * 
	 * @return the fuelGauge
	 */
	public FuelGauge getFuelGauge()
	{
		return fuelGauge;
	}

	/**
	 * return key
	 * 
	 * @return the key
	 */
	public String getKey()
	{
		return key;
	}

	/**
	 * return mpg
	 * 
	 * @return the mgp
	 */
	public double getMgp()
	{
		return mgp;
	}

	/**
	 * return name
	 * 
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * return oil gauge
	 * 
	 * @return the oilGauge
	 */
	public OilGauge getOilGauge()
	{
		return oilGauge;
	}

	/**
	 * return tire gauge
	 * 
	 * @return the tireGauge
	 */
	public TireGauge getTireGauge()
	{
		return tireGauge;
	}

	/**
	 * set fuel gauge
	 * 
	 * @param fuelGauge the fuelGauge to set
	 */
	public void setFuelGauge(FuelGauge fuelGauge)
	{
		this.fuelGauge = fuelGauge;
	}

	/**
	 * set key
	 * 
	 * @param key the key to set
	 */
	public void setKey(String key)
	{
		this.key = key;
	}

	/**
	 * set mpg
	 * 
	 * @param mgp the mgp to set
	 */
	public void setMgp(double mgp)
	{
		this.mgp = mgp;
	}

	/**
	 * set name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * set oil
	 * 
	 * @param oilGauge the oilGauge to set
	 */
	public void setOilGauge(OilGauge oilGauge)
	{
		this.oilGauge = oilGauge;
	}

	/**
	 * set tire
	 * 
	 * @param tireGauge the tireGauge to set
	 */
	public void setTireGauge(TireGauge tireGauge)
	{
		this.tireGauge = tireGauge;
	}

}
