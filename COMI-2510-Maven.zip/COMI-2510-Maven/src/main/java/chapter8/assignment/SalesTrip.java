/**
 * 
 */
package chapter8.assignment;

/**
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class SalesTrip
{

	private String from=null;
	private String to=null;
	private Double distance=0.0;
	private Double duration=0.0;
	
	/**
	 * Default constructor
	 */
	public SalesTrip()
	{
		super();
	}

	public SalesTrip(String from, String to, Double distance, Double duration)
	{
		super();
		this.from = from;
		this.to = to;
		this.distance = distance;
		this.duration = duration;
	}

	/**
	 * @return the distance
	 */
	public Double getDistance()
	{
		return distance;
	}

	/**
	 * @return the duration
	 */
	public Double getDuration()
	{
		return duration;
	}

	/**
	 * @return the from
	 */
	public String getFrom()
	{
		return from;
	}

	/**
	 * @return the to
	 */
	public String getTo()
	{
		return to;
	}

	/**
	 * @param distance the distance to set
	 */
	public void setDistance(Double distance)
	{
		this.distance = distance;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(Double duration)
	{
		this.duration = duration;
	}

	/**
	 * @param from the from to set
	 */
	public void setFrom(String from)
	{
		this.from = from;
	}

	/**
	 * @param to the to to set
	 */
	public void setTo(String to)
	{
		this.to = to;
	}

}
