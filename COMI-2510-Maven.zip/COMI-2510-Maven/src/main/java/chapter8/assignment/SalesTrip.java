/**
 * 
 */
package chapter8.assignment;

/**
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class SalesTrip
{

	/**
	 * Default constructor
	 */
	public SalesTrip()
	{
		super();
	}

}
