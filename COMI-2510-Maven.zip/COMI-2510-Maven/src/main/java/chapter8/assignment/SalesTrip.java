/**
 * 
 */
package chapter8.assignment;

/**
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class SalesTrip
{

	private String from;
	private String to;
	private Double distance;
	private Double duration;
	
	/**
	 * Default constructor
	 */
	public SalesTrip()
	{
		super();
	}

	public SalesTrip(String from, String to, Double distance, Double duration)
	{
		super();
		this.from = from;
		this.to = to;
		this.distance = distance;
		this.duration = duration;
	}

	/**
	 * @return the from
	 */
	public String getFrom()
	{
		return from;
	}

	/**
	 * @param from the from to set
	 */
	public void setFrom(String from)
	{
		this.from = from;
	}

	/**
	 * @return the to
	 */
	public String getTo()
	{
		return to;
	}

	/**
	 * @param to the to to set
	 */
	public void setTo(String to)
	{
		this.to = to;
	}

	/**
	 * @return the distance
	 */
	public Double getDistance()
	{
		return distance;
	}

	/**
	 * @param distance the distance to set
	 */
	public void setDistance(Double distance)
	{
		this.distance = distance;
	}

	/**
	 * @return the duration
	 */
	public Double getDuration()
	{
		return duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(Double duration)
	{
		this.duration = duration;
	}

}
