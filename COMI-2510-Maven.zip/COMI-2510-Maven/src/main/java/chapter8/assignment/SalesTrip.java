/**
 * 
 */
package chapter8.assignment;

/**
 * Sales trip
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class SalesTrip
{

	private String from = null;
	private String to = null;
	private Double distance = 0.0;
	private Double duration = 0.0;

	/**
	 * Default constructor
	 */
	public SalesTrip()
	{
		super();
	}

	/**
	 * constructor 
	 * @param from from 
	 * @param to to 
	 * @param distance distance
	 * @param duration distance 
	 */
	public SalesTrip(String from, String to, Double distance, Double duration)
	{
		super();
		this.from = from;
		this.to = to;
		this.distance = distance;
		this.duration = duration;
	}

	/**
	 * get distance
	 * 
	 * @return the distance
	 */
	public Double getDistance()
	{
		return distance;
	}

	/**
	 * get duration
	 * 
	 * @return the duration
	 */
	public Double getDuration()
	{
		return duration;
	}

	/**
	 * get from
	 * 
	 * @return the from
	 */
	public String getFrom()
	{
		return from;
	}

	/**
	 * get to
	 * 
	 * @return the to
	 */
	public String getTo()
	{
		return to;
	}

	/**
	 * set distance
	 * 
	 * @param distance the distance to set
	 */
	public void setDistance(Double distance)
	{
		this.distance = distance;
	}

	/**
	 * set duration
	 * 
	 * @param duration the duration to set
	 */
	public void setDuration(Double duration)
	{
		this.duration = duration;
	}

	/**
	 * set from
	 * 
	 * @param from the from to set
	 */
	public void setFrom(String from)
	{
		this.from = from;
	}

	/**
	 * set to
	 * 
	 * @param to the to to set
	 */
	public void setTo(String to)
	{
		this.to = to;
	}

}
