/**
 * 
 */
package chapter8.assignment;

/**
 * Tire Gauge
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class TireGauge
{
	private Double maxDistBeforeChange = 0.0;

	/**
	 * Default constructor
	 * 
	 * @param maxDistBeforeChange max dist before change
	 * @param tireAge             tire age
	 */
	public TireGauge(Double maxDistBeforeChange, Double tireAge)
	{
		super();
		this.maxDistBeforeChange = maxDistBeforeChange;
		this.tireAge = tireAge;
	}

	private Double tireAge = 0.0;

	@Override
	public String toString()
	{
		return "TireGauge [maxDistBeforeChange=" + maxDistBeforeChange + ", tireAge=" + tireAge + "]";
	}

	/**
	 * get max dsitance
	 * 
	 * @return the maxDistBeforeChange
	 */
	public Double getMaxDistBeforeChange()
	{
		return maxDistBeforeChange;
	}

	/**
	 * set max distance
	 * 
	 * @param maxDistBeforeChange the maxDistBeforeChange to set
	 */
	public void setMaxDistBeforeChange(Double maxDistBeforeChange)
	{
		this.maxDistBeforeChange = maxDistBeforeChange;
	}

	/**
	 * get tire age
	 * 
	 * @return the tireAge
	 */
	public Double getTireAge()
	{
		return tireAge;
	}

	/**
	 * set tire age
	 * 
	 * @param tireAge the tireAge to set
	 */
	public void setTireAge(Double tireAge)
	{
		this.tireAge = tireAge;
	}

	/**
	 * Default constructor
	 */
	public TireGauge()
	{
		super();
	}

}
