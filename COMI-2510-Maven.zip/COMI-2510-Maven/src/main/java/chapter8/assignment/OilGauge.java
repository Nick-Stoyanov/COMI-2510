/**
 * 
 */
package chapter8.assignment;

/**
 * Test Oil gauge
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class OilGauge
{
	private Double maxDistForOilChange = 0.0;
	private Double oilAge =0.0;
	

	/**
	 * Default constructor
	 * @param maxDistForOilChange max dist to change oil
	 * @param oilAge oil age
	 */
	public OilGauge(Double maxDistForOilChange, Double oilAge)
	{
		super();
		this.maxDistForOilChange = maxDistForOilChange;
		this.oilAge = oilAge;
	}


	@Override
	public String toString()
	{
		return "OilGauge [maxDistForOilChange=" + maxDistForOilChange + ", oilAge=" + oilAge + "]";
	}


	/**
	 * get max distance
	 * @return the maxDistForOilChange
	 */
	public Double getMaxDistForOilChange()
	{
		return maxDistForOilChange;
	}


	/**
	 * set max distance to change oil
	 * @param maxDistForOilChange the maxDistForOilChange to set
	 */
	public void setMaxDistForOilChange(Double maxDistForOilChange)
	{
		this.maxDistForOilChange = maxDistForOilChange;
	}


	/**
	 * get oil age
	 * @return the oilAge
	 */
	public Double getOilAge()
	{
		return oilAge;
	}


	/**
	 * set oil age
	 * @param oilAge the oilAge to set
	 */
	public void setOilAge(Double oilAge)
	{
		this.oilAge = oilAge;
	}


	/**
	 * Default constructor
	 */
	public OilGauge()
	{
		super();
	}

}
