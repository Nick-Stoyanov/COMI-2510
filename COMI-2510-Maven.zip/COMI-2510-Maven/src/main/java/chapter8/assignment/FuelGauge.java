/**
 * 
 */
package chapter8.assignment;

/**
 * Fuel Gauge
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class FuelGauge
{
	@Override
	public String toString()
	{
		return "FuelGauge [maxFuel=" + maxFuel + ", currentFuel=" + currentFuel + "]";
	}

	private Double maxFuel = 0.0;

	/**
	 * Default constructor
	 * 
	 * @param maxFuel     max fuel
	 * @param currentFuel current fuel
	 */
	public FuelGauge(Double maxFuel, Double currentFuel)
	{
		super();
		this.maxFuel = maxFuel;
		this.currentFuel = currentFuel;
	}

	private Double currentFuel = 0.0;

	/**
	 * get max fuel
	 * 
	 * @return the maxFuel
	 */
	public Double getMaxFuel()
	{
		return maxFuel;
	}

	/**
	 * set max fuel
	 * 
	 * @param maxFuel the maxFuel to set
	 */
	public void setMaxFuel(Double maxFuel)
	{
		this.maxFuel = maxFuel;
	}

	/**
	 * get current fuel
	 * 
	 * @return the currentFuel
	 */
	public Double getCurrentFuel()
	{
		return currentFuel;
	}

	/**
	 * set current fuel
	 * 
	 * @param currentFuel the currentFuel to set
	 */
	public void setCurrentFuel(Double currentFuel)
	{
		this.currentFuel = currentFuel;
	}

	/**
	 * default constructor
	 */
	public FuelGauge()
	{
		super();

	}
}
