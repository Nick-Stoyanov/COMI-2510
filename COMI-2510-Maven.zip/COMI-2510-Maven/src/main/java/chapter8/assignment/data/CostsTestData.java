/**
 * 
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.Costs;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class CostsTestData
{

	private ArrayList<Costs> costList = new ArrayList<Costs>();

	/**
	 * Default constructor
	 */
	public CostsTestData()
	{
		super();

		String hondaName = "Honda Accord Hybrid";
		Double hondaPrice = 28335.0;
		Double hondaOilChange = 75.0;
		Double hondaFuelPerGallon = 4.0;
		Double hondaNewTires = 400.0;

		String jeepName = "Jeep Grand Cherokee";
		Double jeepPrice = 37460.0;
		Double jeepOilChange = 75.0;
		Double jeepFuelPerGallon = 4.0;
		Double jeepNewTires = 600.0;

		String lamboName = "Lamborghini Aventador SV";
		Double lamboPrice = 490700.0;
		Double lamboOilChange = 1500.0;
		Double lamboFuelPerGallon = 4.0;
		Double lamboNewTires = 4000.0;

		String ferrariName = "Ferrari F-40";
		Double ferrariPrice = 1900000.0;
		Double ferrariOilChange = 2500.0;
		Double ferrariFuelPerGallon = 4.0;
		Double ferrariNewTires = 5000.0;

		String truckName = "Peterbilt 340 8x4";
		Double truckPrice = 35000.0;
		Double truckOilChange = 750.0;
		Double truckFuelPerGallon = 4.0;
		Double truckNewTires = 3500.0;

		Costs honda = new Costs(hondaName, hondaPrice, hondaOilChange, hondaFuelPerGallon, hondaNewTires);
		costList.add(honda);

		Costs jeep = new Costs(jeepName, jeepPrice, jeepOilChange, jeepFuelPerGallon, jeepNewTires);
		costList.add(jeep);

		Costs lambo = new Costs(lamboName, lamboPrice, lamboOilChange, lamboFuelPerGallon, lamboNewTires);
		costList.add(lambo);

		Costs ferrari = new Costs(ferrariName, ferrariPrice, ferrariOilChange, ferrariFuelPerGallon, ferrariNewTires);
		costList.add(ferrari);

		Costs truck = new Costs(truckName, truckPrice, truckOilChange, truckFuelPerGallon, truckNewTires);
		costList.add(truck);

	}

	/**
	 * @return the costList
	 */
	public ArrayList<Costs> getCostList()
	{
		return costList;
	}

}
