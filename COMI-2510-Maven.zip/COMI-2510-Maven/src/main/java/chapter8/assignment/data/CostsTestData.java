/**
 * 
 */
package chapter8.assignment.data;

/**
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class CostsTestData
{

	/**
	 * Default constructor
	 */
	public CostsTestData()
	{
		super();
	}

}
