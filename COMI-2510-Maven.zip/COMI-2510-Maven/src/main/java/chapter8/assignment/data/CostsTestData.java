/**
 * 
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.Costs;

/**
 * Create list of costs
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class CostsTestData
{

	private ArrayList<Costs> costList = new ArrayList<Costs>();

	/**
	 * Default constructor
	 */
	public CostsTestData()
	{
		super();

		String car1Name = "Honda Accord Hybrid";
		Double car1Price = 28335.0;
		Double car1OilChange = 75.0;
		Double car1FuelPerGallon = 4.0;
		Double car1NewTires = 400.0;

		String car2Name = "Jeep Grand Cherokee";
		Double car2Price = 37460.0;
		Double car2OilChange = 75.0;
		Double car2FuelPerGallon = 4.0;
		Double car2NewTires = 600.0;

		String car3Name = "Lamborghini Aventador SV";
		Double car3Price = 490700.0;
		Double car3OilChange = 1500.0;
		Double car3FuelPerGallon = 4.0;
		Double car3NewTires = 4000.0;

		String car4Name = "Ferrari F-40";
		Double car4Price = 1900000.0;
		Double car4OilChange = 2500.0;
		Double car4FuelPerGallon = 4.0;
		Double car4NewTires = 5000.0;

		String car5Name = "Peterbilt 340 8x4";
		Double car5Price = 35000.0;
		Double car5OilChange = 750.0;
		Double car5FuelPerGallon = 4.0;
		Double car5NewTires = 3500.0;

		Costs honda = new Costs(car1Name, car1Price, car1OilChange, car1FuelPerGallon, car1NewTires);
		costList.add(honda);

		Costs jeep = new Costs(car2Name, car2Price, car2OilChange, car2FuelPerGallon, car2NewTires);
		costList.add(jeep);

		Costs lambo = new Costs(car3Name, car3Price, car3OilChange, car3FuelPerGallon, car3NewTires);
		costList.add(lambo);

		Costs ferrari = new Costs(car4Name, car4Price, car4OilChange, car4FuelPerGallon, car4NewTires);
		costList.add(ferrari);

		Costs truck = new Costs(car5Name, car5Price, car5OilChange, car5FuelPerGallon, car5NewTires);
		costList.add(truck);

	}

	/**
	 * @return the costList
	 */
	public ArrayList<Costs> getCostList()
	{
		return costList;
	}

}
