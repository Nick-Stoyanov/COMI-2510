/**
 * Create automobile list
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.Automobile;
import chapter8.assignment.FuelGauge;
import chapter8.assignment.OilGauge;
import chapter8.assignment.TireGauge;

/**
 * Create list of cars for the trip
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class AutomobileTestData
{

	ArrayList<Automobile> carList = new ArrayList<Automobile>();

	/**
	 * Default constructor
	 */
	public AutomobileTestData()
	{
		super();

		FuelGauge car1FuelGauge = new FuelGauge(22.0, 22.0);
		OilGauge car1OilGauge = new OilGauge(10000.0, 10000.0);
		TireGauge car1TireGauge = new TireGauge(50000.0, 50000.0);
		String car1Name = "Lamborghini Aventador SV";
		String car1Key = "car1";
		Double car1MPG = 11.0;

		FuelGauge car2FuelGauge = new FuelGauge(15.0, 15.0);
		OilGauge car2OilGauge = new OilGauge(8000.0, 8000.0);
		TireGauge car2TireGauge = new TireGauge(40000.0, 40000.0);
		String car2Name = "Ferrari F-40";
		String car2Key = "car2";
		Double car2MPG = 10.0;

		FuelGauge car3FuelGauge = new FuelGauge(120.0, 120.0);
		OilGauge car3OilGauge = new OilGauge(30000.0, 3000.0);
		TireGauge car3TireGauge = new TireGauge(35000.0, 35000.0);
		String car3Name = "Peterbilt 340 8x4";
		String car3Key = "car3";
		Double car3MPG = 5.0;

		Automobile car1 = new Automobile(car1FuelGauge, car1OilGauge, car1TireGauge, car1Name, car1Key, car1MPG);
		carList.add(car1);

		Automobile car2 = new Automobile(car2FuelGauge, car2OilGauge, car2TireGauge, car2Name, car2Key, car2MPG);
		carList.add(car2);

		Automobile car3 = new Automobile(car3FuelGauge, car3OilGauge, car3TireGauge, car3Name, car3Key, car3MPG);
		carList.add(car3);

	}

	/**
	 * Return list
	 * @return the carList
	 */
	public ArrayList<Automobile> getCarList()
	{
		return carList;
	}

}
