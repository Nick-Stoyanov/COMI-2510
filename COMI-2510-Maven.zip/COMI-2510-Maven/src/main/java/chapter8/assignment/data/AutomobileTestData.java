/**
 * 
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.Automobile;
import chapter8.assignment.FuelGauge;
import chapter8.assignment.OilGauge;
import chapter8.assignment.TireGauge;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class AutomobileTestData
{

	/**
	 * Default constructor
	 */
	public AutomobileTestData()
	{
		super();
		ArrayList<Automobile> carList = new ArrayList<Automobile>();

		FuelGauge lamboFuelGauge = new FuelGauge(22.0, 22.0);
		OilGauge lamboOilGauge = new OilGauge(10000.0, 10000.0);
		TireGauge lamboTireGauge = new TireGauge(50000.0, 50000.0);
		String lamboName = "Lamborghini Aventador SV";
		String lamboKey = "lambo";
		Double lamboMPG = 11.0;

		FuelGauge ferrariFuelGauge = new FuelGauge(15.0, 15.0);
		OilGauge ferrariOilGauge = new OilGauge(8000.0, 8000.0);
		TireGauge ferrariTireGauge = new TireGauge(40000.0, 40000.0);
		String ferrariName = "Ferrari F-40";
		String ferrariKey = "rari";
		Double ferrariMPG = 10.0;

		FuelGauge cementTruckFuelGauge = new FuelGauge(120.0, 120.0);
		OilGauge cementTruckOilGauge = new OilGauge(30000.0, 3000.0);
		TireGauge cementTruckTireGauge = new TireGauge(35000.0, 35000.0);
		String cementTruckName = "Peterbilt 340 8x4";
		String cementTruckKey = "truck";
		Double cementTruckMPG = 5.0;

		Automobile lambo = new Automobile(lamboFuelGauge, lamboOilGauge, lamboTireGauge, lamboName, lamboKey, lamboMPG);
		carList.add(lambo);

		Automobile ferrari = new Automobile(ferrariFuelGauge, ferrariOilGauge, ferrariTireGauge, ferrariName,
				ferrariKey, ferrariMPG);
		carList.add(ferrari);

		Automobile cementTruck = new Automobile(cementTruckFuelGauge, cementTruckOilGauge, cementTruckTireGauge,
				cementTruckName, cementTruckKey, cementTruckMPG);
		carList.add(cementTruck);
	}

}
