/**
 * 
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.Automobile;
import chapter8.assignment.FuelGauge;
import chapter8.assignment.OilGauge;
import chapter8.assignment.TireGauge;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class AutomobileTestData
{
	ArrayList<Automobile> carList = new ArrayList<Automobile>();
	/**
	 * Default constructor
	 */
	public AutomobileTestData()
	{
		super();
		

		FuelGauge lamboFuelGauge = new FuelGauge(22.0, 22.0);
		OilGauge lamboOilGauge = new OilGauge(10000.0, 10000.0);
		TireGauge lamboTireGauge = new TireGauge(50000.0, 50000.0);
		String lamboName = "Lamborghini Aventador SV";
		String lamboKey = "car1";
		Double lamboMPG = 11.0;

		FuelGauge ferrariFuelGauge = new FuelGauge(15.0, 15.0);
		OilGauge ferrariOilGauge = new OilGauge(8000.0, 8000.0);
		TireGauge ferrariTireGauge = new TireGauge(40000.0, 40000.0);
		String ferrariName = "Ferrari F-40";
		String ferrariKey = "car2";
		Double ferrariMPG = 10.0;

		FuelGauge cementTruckFuelGauge = new FuelGauge(120.0, 120.0);
		OilGauge cementTruckOilGauge = new OilGauge(30000.0, 3000.0);
		TireGauge cementTruckTireGauge = new TireGauge(35000.0, 35000.0);
		String cementTruckName = "Peterbilt 340 8x4";
		String cementTruckKey = "car3";
		Double cementTruckMPG = 5.0;

		Automobile car1 = new Automobile(lamboFuelGauge, lamboOilGauge, lamboTireGauge, lamboName, lamboKey, lamboMPG);
		carList.add(car1);

		Automobile car2 = new Automobile(ferrariFuelGauge, ferrariOilGauge, ferrariTireGauge, ferrariName,
				ferrariKey, ferrariMPG);
		carList.add(car2);

		Automobile car3 = new Automobile(cementTruckFuelGauge, cementTruckOilGauge, cementTruckTireGauge,
				cementTruckName, cementTruckKey, cementTruckMPG);
		carList.add(car3);
	}
	/**
	 * @return the carList
	 */
	public ArrayList<Automobile> getCarList()
	{
		return carList;
	}

}
