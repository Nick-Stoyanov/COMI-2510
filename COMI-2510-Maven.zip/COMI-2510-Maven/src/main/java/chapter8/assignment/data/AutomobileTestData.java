/**
 * 
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.Automobile;
import chapter8.assignment.FuelGauge;
import chapter8.assignment.OilGauge;
import chapter8.assignment.TireGauge;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class AutomobileTestData
{

	/**
	 * Default constructor
	 */
	public AutomobileTestData()
	{
		super();
		ArrayList<Automobile> carList = new ArrayList<Automobile>();

		FuelGauge fordFuelGauge = new FuelGauge(30.0, 30.0);
		OilGauge fordOilGauge = new OilGauge(20.0, 20.0);
		TireGauge fordTireGauge = new TireGauge(5000., 3000.0);

		FuelGauge ferrariFuelGauge = new FuelGauge(30.0, 30.0);
		OilGauge ferrariOilGauge = new OilGauge(20.0, 20.0);
		TireGauge ferrariTireGauge = new TireGauge(5000., 3000.0);

		FuelGauge cimentTruckFuelGauge = new FuelGauge(30.0, 30.0);
		OilGauge cimentTruckOilGauge = new OilGauge(20.0, 20.0);
		TireGauge cimentTruckTireGauge = new TireGauge(5000., 3000.0);

		Automobile ford = new Automobile(fordFuelGauge, fordOilGauge, fordTireGauge, "Ford", "f", 20);
		carList.add(ford);

		Automobile ferrari = new Automobile(ferrariFuelGauge, ferrariOilGauge, ferrariTireGauge, "Ferrari", "rari", 10);
		carList.add(ferrari);

		Automobile cimentTruck = new Automobile(cimentTruckFuelGauge, cimentTruckOilGauge, cimentTruckTireGauge,
				"Truck", "tr", 5);
		carList.add(cimentTruck);
	}

	@Override
	public String toString()
	{
		return "AutomobileTestData [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}


}
