/**
 * 
 */
package chapter8.assignment.data;

import java.util.ArrayList;

import chapter8.assignment.SalesTrip;

/**
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class SalesTripTestData
{

	private ArrayList<SalesTrip> costs = new ArrayList<SalesTrip>();

	public SalesTripTestData()
	{
		super();

		String firstLegFrom = "Providence";
		String firstLegTo = "Miami";
		Double firstLegTime = 22.5;
		Double firstLegDistance = 1462.7;

		String secondLegFrom = "Miami";
		String secondLegTo = "Dallas";
		Double secondLegTime = 19.75;
		Double secondLegDistance = 1309.1;

		String thirdLegFrom = "Dallas";
		String thirdLegTo = "Los Angeles";
		Double thirdLegTime = 21.5;
		Double thirdLegDistance = 1435.7;

		String fourthLegFrom = "Los Angeles";
		String fourthLegTo = "Seattle";
		Double fourthLegTime = 17.9;
		Double fourthLegDistance = 1135.1;

		String fifthLegFrom = "Seattle";
		String fifthLegTo = "Chicago";
		Double fifthLegTime = 31.0;
		Double fifthLegDistance = 2042.8;

		String sixthLegFrom = "Chicago";
		String sixthLegTo = "New York";
		Double sixthLegTime = 12.1;
		Double sixthLegDistance = 788.9;

		String seventhLegFrom = "New York";
		String seventhLegTo = "Providence";
		Double seventhLegTime = 3.5;
		Double seventhLegDistance = 180.9;

		SalesTrip firstLeg = new SalesTrip(firstLegFrom, firstLegTo, firstLegDistance, firstLegTime);
		costs.add(firstLeg);

		SalesTrip secondLeg = new SalesTrip(secondLegFrom, secondLegTo, secondLegDistance, secondLegTime);
		costs.add(secondLeg);

		SalesTrip thirdLeg = new SalesTrip(thirdLegFrom, thirdLegTo, thirdLegDistance, thirdLegTime);
		costs.add(thirdLeg);

		SalesTrip fourthLeg = new SalesTrip(fourthLegFrom, fourthLegTo, fourthLegDistance, fourthLegTime);
		costs.add(fourthLeg);

		SalesTrip fifthLeg = new SalesTrip(fifthLegFrom, fifthLegTo, fifthLegDistance, fifthLegTime);
		costs.add(fifthLeg);

		SalesTrip sixthLeg = new SalesTrip(sixthLegFrom, sixthLegTo, sixthLegDistance, sixthLegTime);
		costs.add(sixthLeg);

		SalesTrip seventhLeg = new SalesTrip(seventhLegFrom, seventhLegTo, seventhLegDistance, seventhLegTime);
		costs.add(seventhLeg);

	}

	/**
	 * @return the costs
	 */
	public ArrayList<SalesTrip> getCosts()
	{
		return costs;
	}

}
