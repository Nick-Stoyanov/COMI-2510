/**
 * 
 */
package chapter8.assignment;

/**
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class TotalCost
{

	private String name = null;
	private Double totalTireCost = 0.0;
	private Double totalOilChangeCost =0.0;
	private Double totalCostOfFuel = 0.0;
	private Double totalCost = 0.0;
	/**
	 * Default constructor
	 */
	public TotalCost()
	{
		super();
	}
	/**
	 * Default constructor
	 * @param name
	 * @param totalTireCost
	 * @param totalOilChangeCost
	 * @param totalCostOfFuel
	 */
	public TotalCost(String name, Double totalTyreCost, Double totalOilChangeCost, Double totalCostOfFuel, Double totalCost)
	{
		super();
		this.name = name;
		this.totalTireCost = totalTyreCost;
		this.totalOilChangeCost = totalOilChangeCost;
		this.totalCostOfFuel = totalCostOfFuel;
		this.totalCost = totalCost;
	}
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @return the totalCost
	 */
	public Double getTotalCost()
	{
		return totalCost;
	}
	/**
	 * @return the totalCostOfFuel
	 */
	public Double getTotalCostOfFuel()
	{
		return totalCostOfFuel;
	}
	/**
	 * @return the totalOilChangeCost
	 */
	public Double getTotalOilChangeCost()
	{
		return totalOilChangeCost;
	}
	/**
	 * @return the totalTireCost
	 */
	public Double getTotalTireCost()
	{
		return totalTireCost;
	}
	/**
	 * @return the totalTireCost
	 */
	public Double getTotalTyreCost()
	{
		return totalTireCost;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}
	/**
	 * @param totalCost the totalCost to set
	 */
	public void setTotalCost(Double totalCost)
	{
		this.totalCost = totalCost;
	}
	/**
	 * @param totalCostOfFuel the totalCostOfFuel to set
	 */
	public void setTotalCostOfFuel(Double totalCostOfFuel)
	{
		this.totalCostOfFuel = totalCostOfFuel;
	}
	/**
	 * @param totalOilChangeCost the totalOilChangeCost to set
	 */
	public void setTotalOilChangeCost(Double totalOilChangeCost)
	{
		this.totalOilChangeCost = totalOilChangeCost;
	}
	/**
	 * @param totalTireCost the totalTireCost to set
	 */
	public void setTotalTireCost(Double totalTyreCost)
	{
		this.totalTireCost = totalTyreCost;
	}
	@Override
	public String toString()
	{
		return "TotalCost [name=" + name + ", totalTireCost=" + totalTireCost + ", totalOilChangeCost="
				+ totalOilChangeCost + ", totalCostOfFuel=" + totalCostOfFuel + "]";
	}

}
