/**
 * 
 */
package chapter8.assignment;

/**
 * @author Nikolay Stoyanov
 * Dec 2, 2022
 */
public class TotalCost
{

	private String name = null;
	private Double totalTyreCost = 0.0;
	/**
	 * Default constructor
	 * @param name
	 * @param totalTyreCost
	 * @param totalOilChangeCost
	 * @param totalCostOfFuel
	 */
	public TotalCost(String name, Double totalTyreCost, Double totalOilChangeCost, Double totalCostOfFuel)
	{
		super();
		this.name = name;
		this.totalTyreCost = totalTyreCost;
		this.totalOilChangeCost = totalOilChangeCost;
		this.totalCostOfFuel = totalCostOfFuel;
	}
	private Double totalOilChangeCost =0.0;
	private Double totalCostOfFuel = 0.0;
	/**
	 * Default constructor
	 */
	public TotalCost()
	{
		super();
	}
	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}
	/**
	 * @return the totalCostOfFuel
	 */
	public Double getTotalCostOfFuel()
	{
		return totalCostOfFuel;
	}
	/**
	 * @return the totalOilChangeCost
	 */
	public Double getTotalOilChangeCost()
	{
		return totalOilChangeCost;
	}
	/**
	 * @return the totalTyreCost
	 */
	public Double getTotalTyreCost()
	{
		return totalTyreCost;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}
	/**
	 * @param totalCostOfFuel the totalCostOfFuel to set
	 */
	public void setTotalCostOfFuel(Double totalCostOfFuel)
	{
		this.totalCostOfFuel = totalCostOfFuel;
	}
	/**
	 * @param totalOilChangeCost the totalOilChangeCost to set
	 */
	public void setTotalOilChangeCost(Double totalOilChangeCost)
	{
		this.totalOilChangeCost = totalOilChangeCost;
	}
	/**
	 * @param totalTyreCost the totalTyreCost to set
	 */
	public void setTotalTireCost(Double totalTyreCost)
	{
		this.totalTyreCost = totalTyreCost;
	}
	@Override
	public String toString()
	{
		return "TotalCost [name=" + name + ", totalTyreCost=" + totalTyreCost + ", totalOilChangeCost="
				+ totalOilChangeCost + ", totalCostOfFuel=" + totalCostOfFuel + "]";
	}

}
