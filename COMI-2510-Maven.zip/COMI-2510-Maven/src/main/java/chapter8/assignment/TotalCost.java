/**
 * 
 */
package chapter8.assignment;

/**
 * Calculate costs
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class TotalCost
{

	private String name = null;
	private Double totalTireCost = 0.0;
	private Double totalOilChangeCost = 0.0;
	private Double totalCostOfFuel = 0.0;
	private Double totalCost = 0.0;

	/**
	 * Default constructor
	 */
	public TotalCost()
	{
		super();
	}

	/**
	 * Default constructor
	 * 
	 * @param name name
	 * @param totalTireCost tire cost
	 * @param totalOilChangeCost oil cost
	 * @param totalCostOfFuel fuel cost
	 * @param totalCost total cost
	 */
	public TotalCost(String name, Double totalTireCost, Double totalOilChangeCost, Double totalCostOfFuel,
			Double totalCost)
	{
		super();
		this.name = name;
		this.totalTireCost = totalTireCost;
		this.totalOilChangeCost = totalOilChangeCost;
		this.totalCostOfFuel = totalCostOfFuel;
		this.totalCost = totalCost;
	}

	/**
	 * Get name
	 * 
	 * @return the name name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * return total cost
	 * 
	 * @return the totalCost total cost
	 */
	public Double getTotalCost()
	{
		return totalCost;
	}

	/**
	 * return total cost of fuel
	 * 
	 * @return the totalCostOfFuel
	 */
	public Double getTotalCostOfFuel()
	{
		return totalCostOfFuel;
	}

	/**
	 * return total cost of oil
	 * 
	 * @return the totalOilChangeCost
	 */
	public Double getTotalOilChangeCost()
	{
		return totalOilChangeCost;
	}

	/**
	 * return total cost of tires
	 * 
	 * @return the totalTireCost
	 */
	public Double getTotalTireCost()
	{
		return totalTireCost;
	}

	/**
	 * sets name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * total cost
	 * 
	 * @param totalCost the totalCost to set
	 */
	public void setTotalCost(Double totalCost)
	{
		this.totalCost = totalCost;
	}

	/**
	 * get fuel cost
	 * 
	 * @param totalCostOfFuel fuel cost
	 */
	public void setTotalCostOfFuel(Double totalCostOfFuel)
	{
		this.totalCostOfFuel = totalCostOfFuel;
	}

	/**
	 * set total oil cost
	 * 
	 * @param totalOilChangeCost the totalOilChangeCost to set
	 */
	public void setTotalOilChangeCost(Double totalOilChangeCost)
	{
		this.totalOilChangeCost = totalOilChangeCost;
	}

	/**
	 * set tires total
	 * 
	 * @param totalTireCost the totalTireCost to set
	 */
	public void setTotalTireCost(Double totalTireCost)
	{
		this.totalTireCost = totalTireCost;
	}

	@Override
	public String toString()
	{
		return "TotalCost [name=" + name + ", totalTireCost=" + totalTireCost + ", totalOilChangeCost="
				+ totalOilChangeCost + ", totalCostOfFuel=" + totalCostOfFuel + "]";
	}

}
