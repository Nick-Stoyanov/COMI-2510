/**
 * 
 */
package chapter8.assignment;

/**
 * Calculate costs
 * 
 * @author Nikolay Stoyanov Dec 2, 2022
 */
public class Costs
{

	private String name = null;
	private Double newTiresCost = 0.0;
	private Double oilChangeCost = 0.0;

	/**
	 * Defaults constructor 
	 * @param name name
	 * @param carCost cat cost
	 * @param oilChangeCost oil cost
	 * @param fuelPrice fuel cost 
	 * @param newTiresCost tires cost
	 */
	public Costs(String name, Double carCost, Double oilChangeCost, Double fuelPrice, Double newTiresCost)
	{
		super();
		this.name = name;
		this.newTiresCost = newTiresCost;
		this.oilChangeCost = oilChangeCost;
		this.fuelPrice = fuelPrice;
		this.carCost = carCost;
	}

	private Double fuelPrice = 0.0;
	private Double carCost = 0.0;

	@Override
	public String toString()
	{
		return "Costs [name=" + name + ", newTiresCost=" + newTiresCost + ", oilChangeCost=" + oilChangeCost
				+ ", fuelPrice=" + fuelPrice + ", carCost=" + carCost + "]";
	}

	/**
	 * get name
	 * 
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * set name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * get tires cost
	 * 
	 * @return the newTiresCost
	 */
	public Double getNewTiresCost()
	{
		return newTiresCost;
	}

	/**
	 * set tires cost
	 * 
	 * @param newTiresCost the newTiresCost to set
	 */
	public void setNewTiresCost(Double newTiresCost)
	{
		this.newTiresCost = newTiresCost;
	}

	/**
	 * get oil cost
	 * 
	 * @return the oilChangeCost
	 */
	public Double getOilChangeCost()
	{
		return oilChangeCost;
	}

	/**
	 * set oil cost
	 * 
	 * @param oilChangeCost the oilChangeCost to set
	 */
	public void setOilChangeCost(Double oilChangeCost)
	{
		this.oilChangeCost = oilChangeCost;
	}

	/**
	 * get fuel price
	 * 
	 * @return the fuelPrice
	 */
	public Double getFuelPrice()
	{
		return fuelPrice;
	}

	/**
	 * set fuel price
	 * 
	 * @param fuelPrice the fuelPrice to set
	 */
	public void setFuelPrice(Double fuelPrice)
	{
		this.fuelPrice = fuelPrice;
	}

	/**
	 * get car cost
	 * 
	 * @return the carCost
	 */
	public Double getCarCost()
	{
		return carCost;
	}

	/**
	 * set car cost
	 * 
	 * @param carCost the carCost to set
	 */
	public void setCarCost(Double carCost)
	{
		this.carCost = carCost;
	}

	/**
	 * Default constructor
	 */
	public Costs()
	{
		super();
	}

}
