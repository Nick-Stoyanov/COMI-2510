/**
 * 
 */
package chapter8.assignment.test;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import chapter8.assignment.data.AutomobileTestData;
import chapter8.assignment.*;

/**
 * @author Nikolay Stoyanov Dec 10, 2022
 */
public class Test
{
	private static final Logger logger = LogManager.getLogger(Test.class.getName());

	//static ArrayList<TotalCost> totalCost = new ArrayList<TotalCost>();
	static TotalCost totalCar1 = new TotalCost();
	
	static AutomobileTestData carData = new AutomobileTestData();
	/**
	 * Default constructor
	 */
	public Test()
	{
		super();
	}

	public static void main(String[] args)
	{
		
		for (int i = 0; i < carData.getCarList().size(); i++)
		{
			CostPerCar costPerCar = new CostPerCar(carData.getCarList().get(i));
			totalCar1.setName(costPerCar.getName());
			totalCar1.setTotalCostOfFuel(costPerCar.getGasCost());
			totalCar1.setTotalOilChangeCost(costPerCar.getOilCost());
			totalCar1.setTotalTireCost(costPerCar.getTiresCost());
			
			
			
			

			logger.debug("car name " + totalCar1.getName());
			logger.debug("fuel cost " + totalCar1.getTotalCostOfFuel());
			logger.debug("oil cost " + totalCar1.getTotalOilChangeCost());
			logger.debug("tires cost " + totalCar1.getTotalTyreCost());
			logger.debug("total cost " + costPerCar.getTotal());

		}

	}

}
