/**
 * 
 */
package chapter8.assignment.test;

// import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import chapter8.assignment.data.AutomobileTestData;
import chapter8.assignment.*;

/**
 * @author Nikolay Stoyanov Dec 10, 2022
 */
public class Test
{
	private static final Logger logger = LogManager.getLogger(Test.class.getName());

	/**
	 * Default constructor
	 */
	public Test()
	{
		super();
	}

	public static void main(String[] args)
	{
		TotalCost totalCar1 = new TotalCost();
		TotalCost totalCar2 = new TotalCost();
		TotalCost totalCar3 = new TotalCost();
		AutomobileTestData carData = new AutomobileTestData();
		
		CostPerCar costPerCar1 = new CostPerCar(carData.getCarList().get(0));
		totalCar1.setName(costPerCar1.getName());
		logger.debug("car name " + totalCar1.getName());

		totalCar1.setTotalCostOfFuel(costPerCar1.getGasCost());
		logger.debug("fuel cost " + totalCar1.getTotalCostOfFuel());

		totalCar1.setTotalOilChangeCost(costPerCar1.getOilCost());
		logger.debug("oil cost " + totalCar1.getTotalOilChangeCost());

		totalCar1.setTotalTireCost(costPerCar1.getTiresCost());
		logger.debug("tires cost " + totalCar1.getTotalTyreCost());
		double total = (totalCar1.getTotalCostOfFuel() + totalCar1.getTotalOilChangeCost()
		+ totalCar1.getTotalTyreCost() + costPerCar1.getPrice());

		logger.debug("total cost " + total);

		CostPerCar costPerCar2 = new CostPerCar(carData.getCarList().get(1));

		totalCar2.setName(costPerCar2.getName());
		logger.debug("car name " + totalCar2.getName());

		totalCar2.setTotalCostOfFuel(costPerCar2.getGasCost());
		logger.debug("fuel cost " + totalCar2.getTotalCostOfFuel());

		totalCar2.setTotalOilChangeCost(costPerCar2.getOilCost());
		logger.debug("oil cost " + totalCar2.getTotalOilChangeCost());

		totalCar2.setTotalTireCost(costPerCar2.getTiresCost());
		logger.debug("tires cost " + totalCar2.getTotalTyreCost());

		totalCar2.setTotalCost(costPerCar2.getTotal());
		logger.debug("total cost " + totalCar2.getTotalCost());

		CostPerCar costPerCar3 = new CostPerCar(carData.getCarList().get(2));
		totalCar3.setName(costPerCar3.getName());
		logger.debug("car name " + totalCar3.getName());

		totalCar3.setTotalCostOfFuel(costPerCar3.getGasCost());
		logger.debug("fuel cost " + totalCar3.getTotalCostOfFuel());

		totalCar3.setTotalOilChangeCost(costPerCar3.getOilCost());
		logger.debug("oil cost " + totalCar3.getTotalOilChangeCost());

		totalCar3.setTotalTireCost(costPerCar3.getTiresCost());
		logger.debug("tires cost " + totalCar3.getTotalTyreCost());

		totalCar3.setTotalCost(costPerCar3.getTotal());
		logger.debug("total cost " + totalCar3.getTotalCost());

		
	}

}
