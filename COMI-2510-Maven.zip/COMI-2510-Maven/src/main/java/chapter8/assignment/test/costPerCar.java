/**
 * 
 */
package chapter8.assignment.test;

import java.util.ArrayList;

import chapter8.assignment.*;
import chapter8.assignment.data.*;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;

/**
 * @author Nikolay Stoyanov Dec 9, 2022
 */
public class costPerCar
{
	//private static final Logger logger = LogManager.getLogger(costPerCar.class.getName());
	private static Double totalDistance = 0.0;
	static Double totalcost =0.0;

	AutomobileTestData automobileTestData = new AutomobileTestData();
	SalesTripTestData salesTripTestData = new SalesTripTestData();
	CostsTestData costsTestData = new CostsTestData();
	TotalCost totalCost = new TotalCost();

	/**
	 * Default constructor
	 */
	public costPerCar()
	{
		super();
		for (int i = 0; i < salesTripTestData.getCosts().size(); i++)
		{
			totalDistance += salesTripTestData.getCosts().get(i).getDistance();
		}
		ArrayList<Costs> costs = new ArrayList<Costs>();
		Double car1GasCost = 0.0;
		Double car1OilCost = 0.0;
		Double car1TiresCost = 0.0;
		Double car1Price = 0.0;
		
		// Objects here much be the same, compare and decide which metrics to use. ;
		
		int i = 2;

		int refillsCar1 = (int) (totalDistance / automobileTestData.getCarList().get(i).getMgp());
		car1GasCost = (refillsCar1 * costsTestData.getCostList().get(i).getFuelPrice());

		int oilChangesCar1 = (int) (totalDistance
				/ automobileTestData.getCarList().get(i).getOilGauge().getMaxDistForOilChange());
		car1OilCost = (oilChangesCar1 * costsTestData.getCostList().get(i).getOilChangeCost());

		int tireChangesCar1 = (int) (totalDistance
				/ automobileTestData.getCarList().get(i).getTireGauge().getMaxDistBeforeChange());
		car1TiresCost = (tireChangesCar1 * costsTestData.getCostList().get(i).getNewTiresCost());
		
		car1Price = costsTestData.getCostList().get(i).getCarCost();
		System.out.println(car1Price);
		totalcost = car1GasCost + car1OilCost + car1TiresCost + car1Price;
		

		
	}
	public static void main(String[]args) {
		//Double output = totalcost;
		//logger.debug(output);
		
		costPerCar x = new costPerCar();
		
		System.out.println(costPerCar.totalcost);
	}

}
