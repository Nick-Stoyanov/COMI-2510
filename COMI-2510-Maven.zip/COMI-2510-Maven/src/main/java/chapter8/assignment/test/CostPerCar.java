/**
 * 
 */
package chapter8.assignment.test;

import chapter8.assignment.*;
import chapter8.assignment.data.*;

/**
 * Cost per car
 * 
 * @author Nikolay Stoyanov Dec 9, 2022
 */
public class CostPerCar
{

	private static Double totalDistance = 0.0;

	// AutomobileTestData automobileTestData = new AutomobileTestData();
	SalesTripTestData salesTripTestData = new SalesTripTestData();
	CostsTestData costsTestData = new CostsTestData();
	Automobile car = new Automobile();

	private Double gasCost = 0.0;
	private Double oilCost = 0.0;
	private Double tiresCost = 0.0;
	private Double carPrice = 0.0;
	private Double total = 0.0;
	private String name = null;

	/**
	 * Calculate cost per car
	 * 
	 * @param car car
	 */
	public CostPerCar(Automobile car)
	{
		super();
		this.car = car;

		for (int i = 0; i < salesTripTestData.getCosts().size(); i++)
		{
			totalDistance += salesTripTestData.getCosts().get(i).getDistance();
		}

		for (int i = 0; i < costsTestData.getCostList().size(); i++)
		{

			if (car.getName().equals(costsTestData.getCostList().get(i).getName()))
			{

				gasCost = Metrics.getGasCost(SalesTripTestData.getTotalDistance(), car.getMgp(),
						costsTestData.getCostList().get(i).getFuelPrice());

				oilCost = Metrics.getOilCost(SalesTripTestData.getTotalDistance(),
						car.getOilGauge().getMaxDistForOilChange(),
						costsTestData.getCostList().get(i).getOilChangeCost());

				tiresCost = Metrics.getTiresCost(SalesTripTestData.getTotalDistance(),
						car.getTireGauge().getMaxDistBeforeChange(),
						costsTestData.getCostList().get(i).getNewTiresCost());

				carPrice = Metrics.getCarCost(costsTestData.getCostList().get(i).getCarCost());

				name = car.getName();

			}

		}

	}

	/**
	 * get price
	 * 
	 * @return the carPrice
	 */
	public Double getCarPrice()
	{
		return carPrice;
	}

	/**
	 * get gas price
	 * 
	 * @return the gasCost
	 */
	public Double getGasCost()
	{
		return gasCost;
	}

	/**
	 * get name
	 * 
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * get oil price
	 * 
	 * @return the oilCost
	 */
	public Double getOilCost()
	{
		return oilCost;
	}

	/**
	 * get car price
	 * 
	 * @return the price
	 */
	public Double getPrice()
	{
		return carPrice;
	}

	/**
	 * get tires price
	 * 
	 * @return the tiresCost
	 */
	public Double getTiresCost()
	{
		return tiresCost;
	}

	/**
	 * get total
	 * 
	 * @return the total
	 */
	public Double getTotal()
	{
		return total;
	}

	/**
	 * set car price
	 * 
	 * @param carPrice the carPrice to set
	 */
	public void setCarPrice(Double carPrice)
	{
		this.carPrice = carPrice;
	}

	/**
	 * set name
	 * 
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}

}
