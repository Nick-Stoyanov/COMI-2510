/**
 * 
 */
package chapter8.assignment.test;

/**
 * @author Nikolay Stoyanov Dec 6, 2022
 */
/**
 * @author Nikolay Stoyanov Dec 11, 2022
 */
public class Metrics
{
	/**
	 * @param carCost
	 * 
	 * @return
	 */
	public static double getCarCost(double carCost)
	{
		return carCost;
	}

	/**
	 * @param totalDistance
	 * @param mpg
	 * @param gasPrice
	 * 
	 * @return
	 */
	public static double getGasCost(double totalDistance, double mpg, double gasPrice)
	{
		return (((int) (totalDistance / mpg)) * gasPrice);
	}

	/**
	 * @param totalDistance
	 * @param distChangeOil
	 * @param oilChangePrice
	 * 
	 * @return
	 */
	public static double getOilCost(double totalDistance, double distChangeOil, double oilChangePrice)
	{
		return (((int) (totalDistance / distChangeOil)) * oilChangePrice);
	}

	/**
	 * @param totalDistance
	 * @param distChangeTires
	 * @param tiresChangeCost
	 * 
	 * @return
	 */
	public static double getTiresCost(double totalDistance, double distChangeTires, double tiresChangeCost)
	{
		return (((int) (totalDistance / distChangeTires)) * tiresChangeCost);
	}

	/**
	 * Default constructor
	 */
	public Metrics()
	{
		super();
	}

}
