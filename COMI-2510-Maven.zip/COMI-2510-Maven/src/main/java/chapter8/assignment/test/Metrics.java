/**
 * 
 */
package chapter8.assignment.test;

/**
 * Calculate metrics
 * 
 * @author Nikolay Stoyanov Dec 6, 2022
 */

public class Metrics
{
	/**
	 * ge tcar cost
	 * 
	 * @param carCost car cost
	 * 
	 * @return car cost
	 */
	public static double getCarCost(double carCost)
	{
		return carCost;
	}

	/**
	 * get gas cost
	 * 
	 * @param totalDistance distance
	 * @param mpg   mpg
	 * @param gasPrice   gas price
	 * 
	 * @return gas cost
	 */
	public static double getGasCost(double totalDistance, double mpg, double gasPrice)
	{
		return (((int) (totalDistance / mpg)) * gasPrice);
	}

	/**
	 * get oil cost
	 * 
	 * @param totalDistance  distance
	 * @param distChangeOil  oil change distance
	 * @param oilChangePrice oil price
	 * 
	 * @return oil price
	 */
	public static double getOilCost(double totalDistance, double distChangeOil, double oilChangePrice)
	{
		return (((int) (totalDistance / distChangeOil)) * oilChangePrice);
	}

	/**
	 * get tires cost 
	 * @param totalDistance distance
	 * @param distChangeTires distance to change tires
	 * @param tiresChangeCost tire cost
	 *  
	 * @return tire cost
	 */
	public static double getTiresCost(double totalDistance, double distChangeTires, double tiresChangeCost)
	{
		return (((int) (totalDistance / distChangeTires)) * tiresChangeCost);
	}

	/**
	 * Default constructor
	 */
	public Metrics()
	{
		super();
	}

}
