/**
 * 
 */
package chapter8.assignment.test;

/**
 * @author Nikolay Stoyanov Dec 6, 2022
 */
public class Metrics
{
	public static double getCarCost(double carCost)
	{
		return carCost;
	}

	public static double getGasCost(double totalDistance, double mpg, double gasPrice)
	{
		return (((int) (totalDistance / mpg)) * gasPrice);
	}

	public static double getOilCost(double totalDistance, double distChangeOil, double oilChangePrice)
	{
		return (((int) (totalDistance / distChangeOil)) * oilChangePrice);
	}

	public static double getTiresCost(double totalDistance, double distChangeTires, double tiresChangeCost)
	{
		return (((int) (totalDistance / distChangeTires)) * tiresChangeCost);
	}

	public static double getTotal(double totalGas, double totalOil, double totalTires, double carCost)
	{
		return (Metrics.getCarCost(carCost) + Metrics.getGasCost(totalOil, totalTires, carCost)
				+ Metrics.getOilCost(totalOil, totalTires, carCost)
				+ Metrics.getTiresCost(totalOil, totalTires, carCost));
	}

	/**
	 * Default constructor
	 */
	public Metrics()
	{
		super();
	}

}
