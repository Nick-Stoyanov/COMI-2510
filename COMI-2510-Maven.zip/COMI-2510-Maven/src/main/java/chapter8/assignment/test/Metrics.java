/**
 * 
 */
package chapter8.assignment.test;

/**
 * @author Nikolay Stoyanov
 * Dec 6, 2022
 */
public class Metrics
{

	/**
	 * Default constructor
	 */
	public Metrics()
	{
		super();
	}

}
