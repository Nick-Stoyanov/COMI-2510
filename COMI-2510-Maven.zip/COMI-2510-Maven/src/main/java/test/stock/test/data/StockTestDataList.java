/**
 * Stock test data list
 */
package test.stock.test.data;

import java.util.ArrayList;
import java.util.Iterator;

import test.stock.stock.Stock;

/**
 * Stock test data list
 *
 * @author dean grammas
 *
 */
public class StockTestDataList
{
    /**
     * Stock object
     */
    private ArrayList<Stock> stockList;
    
    /**
     * Constructor
     */
    public StockTestDataList()
    {
	super();
	
	ArrayList<Stock> list = new ArrayList<Stock>();
	
	Stock companyStock = new Stock(StockTestData.SYMBOL, StockTestData.STOCK_PRICE, StockTestData.NUM_SHARES);
	list.add(companyStock);
	
	for (int i = 0; i < 10; i++)
	{
	    // add more stocks, with the number as the stock name
	    companyStock = new Stock(Integer.toString(i), (StockTestData.STOCK_PRICE + i),
		    (StockTestData.NUM_SHARES + i));
	    list.add(companyStock);
	}
	
	this.setStockList(list);
    }
    
    /**
     * Returns the <code>Stock</code>
     *
     * @param symmbol - symbol
     * @return the <code>Stock</code>
     */
    public Stock getStock(String symmbol)
    {
	Iterator<Stock> iter = this.getStockList().iterator();
	Stock element = null;
	while (iter.hasNext())
	{
	    element = iter.next();
	    if (element.getSymbol().equals(symmbol))
	    {
		return element;
	    }
	}
	return null;
    }
    
    /**
     * Get stock list
     *
     * @return the stockList
     */
    public ArrayList<Stock> getStockList()
    {
	return this.stockList;
    }
    
    /**
     * Set stock list
     *
     * @param stockList the stockList to set
     */
    protected void setStockList(ArrayList<Stock> stockList)
    {
	this.stockList = stockList;
    }
    
    /**
     * String representation of the object
     *
     * @return string representation of the object
     */
    @Override
    public String toString()
    {
	StringBuilder sb = new StringBuilder();
	
	sb.append(this.getClass());
	for (Stock element : this.getStockList())
	{
	    sb.append("\n").append(element.toString());
	}
	return sb.toString();
    }
    
}
