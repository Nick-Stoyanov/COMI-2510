/**
 * Stock list test
 */
package test.stock.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Stock list test
 *
 * @author dean grammas
 *
 */
public class StockListTest
{
    /**
     * Get an instance of the Logger
     */
    private static final Logger logger = LogManager.getLogger(StockListTest.class.getName());
    
    /**
     * Stock list test utility
     */
    private static StockListTestUtility stockListTestUtility;
    
    /**
     * Get stock list test utility
     *
     * @return the stockListTestUtility
     */
    public static StockListTestUtility getStockListTestUtility()
    {
	return stockListTestUtility;
    }
    
    /**
     * Main
     *
     * @param args - ignored
     */
    public static void main(String[] args)
    {
	// create the stock test utility object. Everything that is not related to display will go into this utility
	StockListTest.setStockListTestUtility(new StockListTestUtility());

	String output = StockListTest.getStockListTestUtility().identifyStock();
	logger.debug(output);

	output = StockListTest.getStockListTestUtility().identifyStockExchange();
	logger.debug(output);
	
	logger.debug("Have a great day!");

    }
    
    /**
     * Set stock list test utility
     *
     * @param stockListTestUtility the stockListTestUtility to set
     */
    private static void setStockListTestUtility(StockListTestUtility stockListTestUtility)
    {
	StockListTest.stockListTestUtility = stockListTestUtility;
    }
    
    /**
     * Default Constructor
     */
    public StockListTest()
    {
	super();
    }
}
