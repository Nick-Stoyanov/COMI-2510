/**
 * Stock list test utility
 */
package test.stock.test;

import test.stock.stock.Stock;
import test.stock.stock.StockExchange;
import test.stock.test.data.StockExchangeTestDataList;
import test.stock.test.data.StockTestDataList;

/**
 * Stock list test utility
 *
 * @author dean grammas
 *
 */
public class StockListTestUtility
{
    /**
     * stock list data list
     */
    private StockExchangeTestDataList stockExchangeTestDataList;
    
    /**
     * stock list data list
     */
    private StockTestDataList stockTestDataList;
    
    /**
     * Default constructor
     */
    public StockListTestUtility()
    {
	super();
	
	this.setStockTestDataList(new StockTestDataList());
	this.setStockExchangeTestDataList(new StockExchangeTestDataList());
    }
    
    /**
     * Get stock exchange list data list
     *
     * @return the stockExchangeTestDataList
     */
    protected StockExchangeTestDataList getStockExchangeTestDataList()
    {
	return this.stockExchangeTestDataList;
    }
    
    /**
     * Set stock list data list
     *
     * @return the stockTestDataList
     */
    protected StockTestDataList getStockTestDataList()
    {
	return this.stockTestDataList;
    }
    
    /**
     * Identify stock exchange for each stock
     *
     * @return identified stock exchange for each stock
     */
    public String identifyStock()
    {
	StringBuilder sb = new StringBuilder();
	StockExchange stockExchange = null;
	
	for (Stock stock : this.getStockTestDataList().getStockList())
	{
	    sb.append("\n");
	    sb.append("Symbol is: ").append(stock.getSymbol()).append(". ");
	    stockExchange = this.getStockExchangeTestDataList().getStockExchange(stock.getSymbol());
	    if (null == stockExchange)
	    {
		sb.append("No exchange identified!");
	    } else
	    {
		sb.append("Identified exchange is: ").append(stockExchange.getExchange());
	    }
	}
	return sb.toString();
    }
    
    /**
     * Identify stocks in each stock exchange
     *
     * @return identified stocks in each stock exchange
     */
    public String identifyStockExchange()
    {
	StringBuilder sb = new StringBuilder();
	Stock stock = null;
	
	for (StockExchange stockExchange : this.getStockExchangeTestDataList().getStockExchangeList())
	{
	    sb.append("\n");
	    sb.append("Exchange is: ").append(stockExchange.getExchange()).append(". ");
	    stock = this.getStockTestDataList().getStock(stockExchange.getSymbol());
	    if (null == stock)
	    {
		sb.append("No symbol identified!");
	    } else
	    {
		sb.append("Identified symbol is: ").append(stock.getSymbol());
	    }
	}
	return sb.toString();
    }
    
    /**
     * Set stock exchange list data list
     *
     * @param stockExchangeTestDataList the stockExchangeTestDataList to set
     */
    protected void setStockExchangeTestDataList(StockExchangeTestDataList stockExchangeTestDataList)
    {
	this.stockExchangeTestDataList = stockExchangeTestDataList;
    }
    
    /**
     * Set stock list data list
     *
     * @param stockTestDataList the stockTestDataList to set
     */
    protected void setStockTestDataList(StockTestDataList stockTestDataList)
    {
	this.stockTestDataList = stockTestDataList;
    }
    
}
