/**
 * Stock test data list
 */
package test.stock.test.data;

import java.util.ArrayList;

import test.stock.stock.StockExchange;

/**
 * Stock test data list
 *
 * @author dean grammas
 *
 */
public class StockExchangeTestDataList
{
    /**
     * Stock object
     */
    private ArrayList<StockExchange> stockExchangeList;
    
    /**
     * Constructor
     */
    public StockExchangeTestDataList()
    {
	super();
	
	ArrayList<String> exchange = new ArrayList<String>();
	ArrayList<StockExchange> list = new ArrayList<StockExchange>();
	StockExchange stockExchange = null;
	
	// add the exchanges
	exchange.add("NYSE");
	exchange.add("NASDAQ");
	exchange.add("OTC");
	
	for (int i = 6; i > 0; i--)
	{
	    // add more stocks, with the number as the stock name
	    stockExchange = new StockExchange(Integer.toString(i), exchange.get(i % 3));
	    list.add(stockExchange);
	}
	
	stockExchange = new StockExchange(StockTestData.SYMBOL, exchange.get(0));
	list.add(stockExchange);
	
	this.setStockExchangeList(list);
    }
    
    /**
     * Returns the <code>StockExchange</code>
     *
     * @param symbol - symbol
     * @return the <code>StockExchange</code>
     */
    public StockExchange getStockExchange(String symbol)
    {
	for (StockExchange element : this.getStockExchangeList())
	{
	    if (element.getSymbol().equals(symbol))
	    {
		return element;
	    }
	}
	return null;
    }
    
    /**
     * Get stock exchange list
     *
     * @return the stockExchangeList
     */
    public ArrayList<StockExchange> getStockExchangeList()
    {
	return this.stockExchangeList;
    }
    
    /**
     * Set stock exchange list
     *
     * @param stockExchangeList the stockExchangeList to set
     */
    protected void setStockExchangeList(ArrayList<StockExchange> stockExchangeList)
    {
	this.stockExchangeList = stockExchangeList;
    }
    
    /**
     * String representation of the object
     *
     * @return string representation of the object
     */
    @Override
    public String toString()
    {
	StringBuilder sb = new StringBuilder();
	
	sb.append(this.getClass());
	for (StockExchange element : this.getStockExchangeList())
	{
	    sb.append("\n").append(element.toString());
	}
	return sb.toString();
    }
}
