/**
 * Stock exchange
 */
package test.stock.stock;

/**
 * Stock exchange
 *
 * @author dean grammas
 *
 */
public class StockExchange
{
    /**
     * Exchange for the trading symbol of the stock
     */
    private String exchange;
    /**
     * Trading symbol of stock
     */
    private String symbol;
    
    /**
     * Constructor
     *
     * @param symbol   - symbol
     * @param exchange - exchange
     */
    public StockExchange(String symbol, String exchange)
    {
	super();
	this.symbol = symbol;
	this.exchange = exchange;
    }
    
    /**
     * Get exchange for the trading symbol of the stock
     *
     * @return the exchange
     */
    public String getExchange()
    {
	return this.exchange;
    }
    
    /**
     * getSymbol method
     *
     * @return The stock's trading sysmbol.
     */
    
    public String getSymbol()
    {
	return symbol;
    }
    
    /**
     * Set exchange for the trading symbol of the stock
     *
     * @param exchange the exchange to set
     */
    public void setExchange(String exchange)
    {
	this.exchange = exchange;
    }
    
    /**
     * Set symbol
     *
     * @param symbol the symbol to set
     */
    public void setSymbol(String symbol)
    {
	this.symbol = symbol;
    }
}
