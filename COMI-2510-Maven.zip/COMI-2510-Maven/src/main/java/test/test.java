/**
 * 
 */
package test;

import java.util.ArrayList;

import chapter8.assignment.Automobile;
import chapter8.assignment.FuelGauge;
import chapter8.assignment.OilGauge;
import chapter8.assignment.TireGauge;

/**
 * @author Nikolay Stoyanov Dec 8, 2022
 */
public class test
{

	/**
	 * Default constructor
	 */
	public test()
	{
		super();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		ArrayList<Automobile> carList = new ArrayList<Automobile>();

		FuelGauge fordFuelGauge = new FuelGauge(30.0, 30.0);
		OilGauge fordOilGauge = new OilGauge(20.0, 20.0);
		TireGauge fordTireGauge = new TireGauge(5000., 3000.0);

		FuelGauge ferrariFuelGauge = new FuelGauge(30.0, 30.0);
		OilGauge ferrariOilGauge = new OilGauge(20.0, 20.0);
		TireGauge ferrariTireGauge = new TireGauge(5000., 3000.0);

		FuelGauge cimentTruckFuelGauge = new FuelGauge(30.0, 30.0);
		OilGauge cimentTruckOilGauge = new OilGauge(20.0, 20.0);
		TireGauge cimentTruckTireGauge = new TireGauge(5000., 3000.0);

		Automobile ford = new Automobile(fordFuelGauge, fordOilGauge, fordTireGauge, "Ford", "f", 20);
		carList.add(ford);

		Automobile ferrari = new Automobile(ferrariFuelGauge, ferrariOilGauge, ferrariTireGauge, "Ferrari", "rari", 10);
		carList.add(ferrari);

		Automobile cimentTruck = new Automobile(cimentTruckFuelGauge, cimentTruckOilGauge, cimentTruckTireGauge,
				"Truck", "tr", 5);
		carList.add(cimentTruck);
		System.out.println(carList.get(1).getMgp());
	}


}
