/**
 * 
 */
package test;

import java.util.ArrayList;

import chapter8.assignment.Automobile;
import chapter8.assignment.FuelGauge;
import chapter8.assignment.OilGauge;
import chapter8.assignment.TireGauge;

/**
 * @author Nikolay Stoyanov Dec 8, 2022
 */
public class test
{

	public static void main(String[] args)
	{
		Double x = 5000.0;
		Double y = 16433.2;
		
		int z = (int) (y/x);
		
		System.out.println(z);
	}
}